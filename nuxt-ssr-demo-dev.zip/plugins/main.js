import Vue from 'vue'
// import Header from '@/components/header'
import Input from '@/components/input'
import Icon from '@/components/icon'

// Vue.component(Header.name, Header)
Vue.component(Input.name, Input)
Vue.component(Icon.name, Icon)
