import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _8c789e5e = () => interopDefault(import('..\\pages\\books.vue' /* webpackChunkName: "pages_books" */))
const _2af87de8 = () => interopDefault(import('..\\pages\\repos.vue' /* webpackChunkName: "pages_repos" */))
const _8f6bc6e2 = () => interopDefault(import('..\\pages\\events\\all.vue' /* webpackChunkName: "pages_events_all" */))
const _0fe662f9 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))
const _be43512e = () => interopDefault(import('..\\pages\\index\\index.vue' /* webpackChunkName: "pages_index_index" */))
const _212fad31 = () => interopDefault(import('..\\pages\\index\\_welcome\\_category.vue' /* webpackChunkName: "pages_index__welcome__category" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/books",
    component: _8c789e5e,
    name: "books"
  }, {
    path: "/repos",
    component: _2af87de8,
    name: "repos"
  }, {
    path: "/events/all",
    component: _8f6bc6e2,
    name: "events-all"
  }, {
    path: "/",
    component: _0fe662f9,
    children: [{
      path: "",
      component: _be43512e,
      name: "index"
    }, {
      path: ":welcome/:category?",
      component: _212fad31,
      name: "index-welcome-category"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
